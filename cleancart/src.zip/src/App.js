//import logo from './logo.svg';
import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Cart from './Cart';
import Home from './Home';
import {CartProvider} from "react-use-cart";


function App() {
  return (
    <div>
    <CartProvider>
    {/*<h1 className='text text-success'>Cart App</h1>*/}
     <Home/>
     <Cart/>
    </CartProvider>
    </div>
  );
}

export default App;
