import img1 from "./Images/img1.jpg"
import img2 from "./Images/img2.jpg"
import img3 from "./Images/img3.jpg"
import kashmir from "./Images/kashmir.jpg";
import img4 from "./Images/img4.jpg"
const Data={
    productData:

    [
        {
            id:1,
            img:img1,
            title:"Lord Rama Potrait",
            desc:"16*24 Size",
            price:`$ 4999`,
        },
        {
            id:2,
            img:img2,
            title:"Lord Shiva Potrait",
            desc:"16*34 Size",
            price:`$ 6999`,
        },
        {
            id:3,
            img:img3,
            title:"Lord Anjaneya Potrait",
            desc:"18*24 Size",
            price:`$ 7999`,
        },
        {
            id:4,
            img:kashmir,
            title:"Nature Potrait",
            desc:"20*26 Size",
            price:`$ 1999`,
        },
        {
            id:5,
            img:img4,
            title:"Tiger Potrait",
            desc:"16*26 Size",
            price:`$ 2999`,
        },

    ]
}
export default Data;

