import React, { Component } from 'react';
import { BrowserRouter as Router,Routes, Route, Link } from 'react-router-dom';
import Home from './components/Home';
import Services from './components/Services';
import  Projects from './components/Projects'
import Contact from './components/Contact';


 
class App extends Component {
  render() {
    return (
     
     
       <Router>
           <div className="App">
            <ul className="App-header">
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/Projects">Projects</Link>
              </li>
              <li>
                <Link to="/Services">Services</Link>
              </li>
              <li>
                <Link to="/Contact">Contact</Link>
              </li>
            </ul>
           <Routes>
                 <Route exact path='/' element={< Home />}></Route>
                 <Route exact path='/Projects' element={< Projects />}></Route>
                 <Route exact path='/Services' element={< Services />}></Route>
                 <Route exact path='/Contact' element={< Contact />}></Route>
          </Routes>
          </div>
       </Router>
   );
  }
}
 
export default App;
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <h1>hello world</h1>
//     </div>
//   );
// }

// export default App;
