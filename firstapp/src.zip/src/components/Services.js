import React from 'react';
 
function Services (){
    return <h1>Welcome to Services</h1>
}
 
export default Services;