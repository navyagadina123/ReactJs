import React from 'react';
function Projects (){
    return <h1>Welcome to Projects</h1>
}
 
export default Projects;