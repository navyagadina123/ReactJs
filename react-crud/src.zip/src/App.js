import {React,Component } from 'react';
import './App.css';


class App extends Component{
  constructor(){
    super();
    this.state={
      title : "React Crud Operations",
      act : 0,
      idx: '',
      employeeData :[]
    }
  }
  componentDidMount(){
    this.refs.txtname.focus();
  }
  handleSubmit = (e) => {
    e.preventDefault();
    let employeeData = this.state.employeeData;
    let name = this.refs.txtname.value;
    let job = this.refs.txtjob.value;

    if(this.state.act ===0){
      let newEmployee = {
        "name": name,
        "job": job
      }
      employeeData.push(newEmployee);
    }
   else{
    let index = this.state.idx;
    employeeData[index].name=name;
    employeeData[index].job=job;
    
   }

    this.setState({
      employeeData : employeeData,
      act: 0
    })

    this.refs.myForm.reset();
    this.refs.txtname.focus();
    
  }

  handleEdit = (index) => {
    let employeeData = this.state.employeeData[index];
    this.refs.txtname.value= employeeData.name;
    this.refs.txtjob.value= employeeData.job;

    this.setState({
       data :employeeData,
       act:1,
       idx:index
    })
  }
 

  handleDelete = (index) =>{
    let employeeData = this.state.employeeData;
    employeeData.splice(index,1);
    this.setState({
      employeeData : employeeData
    });
    this.refs.txtname.focus();
  }
  render(){
    let employeeData = this.state.employeeData;
    return(
      <div>
        
      <form ref="myForm" className="myForm">
      <h1>{this.state.title}</h1>
      <h2>Add Employee</h2>
        <label>Name</label>
        <input type="text" ref="txtname" placeholder="Enter Name" className="formField"/>
        
        <label>Job</label>
        <input type="text" ref="txtjob" placeholder="Enter job" className="formField" />
        
        <button onClick={e=>this.handleSubmit(e)} className="myButton">Submit</button>
      </form>
      <pre className="listView">
      <table className='table'/>
        
      <table>
        <tr>
          <th>Name</th>
          <th>Job</th>
          <th>Serial No</th>
            <th>Delete</th>
            <th>Edit</th>
        </tr>

        {
          employeeData.map ( (data,index) =>
             <tr key={index}>
          <td>{index+1}</td>
            <td>{data.name}</td>
            <td>{data.job}</td>

             <td>
              <button onClick= {e=>this.handleEdit(index)} className="myListButton">Edit</button>
            </td> 
            
            <td>
              <button onClick= {e=>this.handleDelete(index)} className="myListButton">Delete</button>
            </td>
           
          </tr>           
        
        )
      }
      </table>
    </pre>
  </div>
 )
}
}

export default App;